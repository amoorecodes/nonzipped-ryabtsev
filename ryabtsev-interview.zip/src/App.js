import logo from "./logo.svg";
import "./App.css";
import WebStore from "./WebStore";

function App() {
  return (
    <div className="App">
      {/* <header className="App-header"></header> */}
      <main>
        <WebStore />
      </main>
    </div>
  );
}

export default App;
